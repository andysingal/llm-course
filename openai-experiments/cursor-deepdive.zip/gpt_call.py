import openai

def call_gpt4_model(prompt):
    response = openai.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content

# Example usage
if __name__ == "__main__":
    prompt = "What is the weather like in New York?"
    result = call_gpt4_model(prompt)
    print(result)
