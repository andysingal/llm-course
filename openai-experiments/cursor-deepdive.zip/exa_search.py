from exa_py import Exa
import os
from datetime import datetime, timedelta

def exa_search(query):
    # Initialize the exa client
    client = Exa(api_key=os.getenv("EXA_API_KEY"))

    # Define the date range for the last 7 days
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')

    # Perform the search with the date range and return contents as well
    results = client.search_and_contents(query, start_published_date=start_date, end_published_date=end_date, num_results=2)

    # Process and return the results
    return results

# Example usage
if __name__ == "__main__":
    query = "latest ai news"
    search_results = exa_search(query)
    print(search_results)