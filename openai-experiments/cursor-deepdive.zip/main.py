import os
from datetime import datetime, timedelta
from exa_py import Exa
import openai

def exa_search(query):
    # Initialize the exa client
    client = Exa(api_key=os.getenv("EXA_API_KEY"))

    # Define the date range for the last 7 days
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')

    # Perform the search with the date range and return contents as well
    results = client.search_and_contents(query, start_published_date=start_date, end_published_date=end_date, num_results=10)

    # Process and return the results
    return results

def call_gpt4_model(prompt):
    response = openai.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content

def main():
    # Take user input for the search query
    query = input("Enter your search query: ")

    # Get search results from Exa
    search_results = exa_search(query)

    # Format the search results into a prompt for GPT-4
    formatted_results = search_results
    prompt = f"Based on the following search results, answer the user's question:\n\n{formatted_results}\n\nQuestion: {query}"

    # Get the answer from GPT-4
    answer = call_gpt4_model(prompt)

    # Print the answer
    print("Answer:", answer)

if __name__ == "__main__":
    main()
